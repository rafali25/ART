#!/usr/bin/env python3
"""Checks a downloaded copy of this deposit: python3 integrity/verify_release.py [root]   (root = folder with the unpacked core.tar.gz; default: the folder above integrity/).
1) every line of integrity/SHA256SUMS; 2) for every analysis stage, the sha256 of each archive member against <stage>.members.sha256.
Layouts understood: folder tree (models_alignments/<stage>.tar.gz) and the flat Zenodo record (<stage>.tar.gz or <stage>.tar.gz.part001, .part002, ...; *.members.sha256 inside core.tar.gz under models_alignments/).
Standard library only."""
import glob, hashlib, io, os, sys, tarfile
root = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
bad = 0; n = 0
class Parts(io.RawIOBase):
    """Reads several files as one stream."""
    def __init__(self, paths): self.paths = list(paths); self.i = 0; self.f = open(self.paths[0], "rb")
    def readable(self): return True
    def readinto(self, b):
        while True:
            k = self.f.readinto(b)
            if k: return k
            self.f.close(); self.i += 1
            if self.i >= len(self.paths): return 0
            self.f = open(self.paths[self.i], "rb")
def sources(rel):
    """list of files that make up the archive/file `rel` (whole file or numbered parts), searched in the tree and in the flat root."""
    for base in (os.path.join(root, rel), os.path.join(root, os.path.basename(rel))):
        if os.path.exists(base): return [base]
        parts = sorted(glob.glob(base + ".part*"))
        if parts: return parts
    return []
def sha(paths):
    d = hashlib.sha256(); s = Parts(paths)
    for b in iter(lambda: s.read(1 << 20), b""): d.update(b)
    return d.hexdigest()
for line in open(os.path.join(root, "integrity", "SHA256SUMS")):
    h, rel = line.rstrip("\n").split("  ", 1); n += 1; src = sources(rel)
    if not src: print("MISSING", rel); bad += 1; continue
    if sha(src) != h: print("MISMATCH", rel); bad += 1
print(n, "files checked against integrity/SHA256SUMS")
m_ok = 0
for mf in sorted(glob.glob(os.path.join(root, "models_alignments", "*.members.sha256")) + glob.glob(os.path.join(root, "*.members.sha256"))):
    stage = os.path.basename(mf)[:-len(".members.sha256")]; src = sources("models_alignments/" + stage + ".tar.gz")
    if not src: print("ARCHIVE MISSING", stage); bad += 1; continue
    want = {}
    for line in open(mf):
        h, s, name = line.rstrip("\n").split("  ", 2); want[name] = (h, int(s))
    with tarfile.open(fileobj=io.BufferedReader(Parts(src), 1 << 20), mode="r|gz") as t:
        for m in t:
            if not m.isfile(): continue
            h = hashlib.sha256(t.extractfile(m).read()).hexdigest()
            if want.pop(m.name, None) != (h, m.size): print("MEMBER MISMATCH", stage, m.name); bad += 1
            else: m_ok += 1
    for name in want: print("MEMBER MISSING", stage, name); bad += 1
print(m_ok, "archive members verified")
print("ALL OK" if bad == 0 else f"{bad} PROBLEM(S)"); sys.exit(1 if bad else 0)
